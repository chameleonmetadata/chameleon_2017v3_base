/*
Navicat MySQL Data Transfer

Source Server         : Chameleon 2017v3
Source Server Version : 50635
Source Host           : chameleonmetadata.com
Source Database       : chameleon_2017v3_base

Target Server Type    : MYSQL
Target Server Version : 50635
File Encoding         : 65001

Author: Eric Thornton (et@chameleonmetadata.com)

Date: 2017-03-06 11:12:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for chameleon_class_facet_type
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_class_facet_type`;
CREATE TABLE `chameleon_class_facet_type` (
  `chameleon_facet_type_key` int(11) NOT NULL AUTO_INCREMENT,
  `facet_type_name` varchar(255) NOT NULL,
  `facet_type_description` varchar(128) DEFAULT NULL,
  `facet_type_owner` int(11) DEFAULT NULL,
  `facet_type_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_facet_type_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`chameleon_facet_type_key`),
  UNIQUE KEY `uix_facet_type_cftk` (`chameleon_facet_type_key`) USING BTREE,
  KEY `uix_facet_type_cftn` (`facet_type_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_class_facet_value
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_class_facet_value`;
CREATE TABLE `chameleon_class_facet_value` (
  `class_facet_value_key` int(11) NOT NULL AUTO_INCREMENT,
  `classification_facet_key` int(11) NOT NULL,
  `cfv_value_alpha` varchar(255) DEFAULT NULL,
  `cfv_value_integer` int(11) DEFAULT NULL,
  `cfv_value_decimal_11_2` decimal(11,2) DEFAULT NULL,
  `cfv_value_decimal_27_7` decimal(27,7) DEFAULT NULL,
  `classification_facet_owner` int(11) DEFAULT NULL,
  `classification_facet_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_facet_value_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`class_facet_value_key`),
  UNIQUE KEY `uix_classification_facet_value_cfvk` (`class_facet_value_key`) USING BTREE,
  KEY `ix_classification_facet_value_cfk` (`classification_facet_key`) USING BTREE,
  KEY `uix_classification_facet_value_cfvva` (`cfv_value_alpha`) USING BTREE,
  CONSTRAINT `chameleon_class_facet_value_ibfk_1` FOREIGN KEY (`classification_facet_key`) REFERENCES `chameleon_classification_facet` (`classification_facet_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_classification_facet
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_classification_facet`;
CREATE TABLE `chameleon_classification_facet` (
  `classification_facet_key` int(11) NOT NULL AUTO_INCREMENT,
  `classification_facet_name` varchar(255) NOT NULL,
  `facet_type_key` int(11) NOT NULL,
  `data_domain_key` int(11) DEFAULT NULL,
  `parent_classification_facet_key` int(11) DEFAULT NULL,
  `classification_facet_owner` int(11) DEFAULT NULL,
  `classification_facet_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_class_facet_key` int(11) DEFAULT NULL,
  `chameleon_source_system_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`classification_facet_key`),
  UNIQUE KEY `UIX_CLASS_FACET_KEY` (`classification_facet_key`) USING BTREE,
  UNIQUE KEY `UIX_FACTYP_DOMAIN_CFK` (`facet_type_key`,`data_domain_key`,`classification_facet_key`) USING BTREE,
  KEY `FK_CLASS_FACET_2_DOMAIN` (`data_domain_key`) USING BTREE,
  KEY `FK_CLASS_FACET_2_OWNER` (`classification_facet_owner`) USING BTREE,
  KEY `FK_CLASS_FACET_2_LOADER` (`classification_facet_steward`) USING BTREE,
  CONSTRAINT `chameleon_classification_facet_ibfk_1` FOREIGN KEY (`data_domain_key`) REFERENCES `chameleon_data_domain` (`chameleon_data_domain_key`),
  CONSTRAINT `chameleon_classification_facet_ibfk_2` FOREIGN KEY (`facet_type_key`) REFERENCES `chameleon_class_facet_type` (`chameleon_facet_type_key`),
  CONSTRAINT `chameleon_classification_facet_ibfk_3` FOREIGN KEY (`classification_facet_steward`) REFERENCES `person_party` (`person_party_key`),
  CONSTRAINT `chameleon_classification_facet_ibfk_4` FOREIGN KEY (`classification_facet_owner`) REFERENCES `person_party` (`person_party_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_data_domain
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_data_domain`;
CREATE TABLE `chameleon_data_domain` (
  `chameleon_data_domain_key` int(11) NOT NULL AUTO_INCREMENT,
  `data_domain_name` varchar(255) NOT NULL,
  `udef_property_key` int(11) DEFAULT NULL,
  `parent_data_domain` int(11) DEFAULT NULL,
  `data_domain_description` varchar(512) DEFAULT NULL,
  `data_domain_owner` int(11) DEFAULT NULL,
  `data_domain_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_data_domain_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`chameleon_data_domain_key`),
  UNIQUE KEY `uix_data_domain_cddk` (`chameleon_data_domain_key`) USING BTREE,
  KEY `uix_data_domain_ddn` (`data_domain_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_data_lifecycle_phase
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_data_lifecycle_phase`;
CREATE TABLE `chameleon_data_lifecycle_phase` (
  `data_lifecycle_phase_key` int(11) NOT NULL AUTO_INCREMENT,
  `data_lifecycle_phase_name` varchar(255) NOT NULL,
  `chameleon_metadata_build_id` varchar(64) CHARACTER SET utf8 DEFAULT '2017v3',
  `date_active` timestamp NULL DEFAULT NULL,
  `date_expiry` timestamp NULL DEFAULT NULL,
  `replacement_data_lifecycle_phase_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`data_lifecycle_phase_key`),
  UNIQUE KEY `uix_data_lifecycle_phase_1` (`data_lifecycle_phase_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for chameleon_dataset_registration
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_dataset_registration`;
CREATE TABLE `chameleon_dataset_registration` (
  `registered_dataset_key` int(11) NOT NULL AUTO_INCREMENT,
  `org_config_master_key` int(11) DEFAULT NULL,
  `registered_dataset_steward` int(11) DEFAULT NULL,
  `dv_record_content_type_key` int(11) DEFAULT NULL,
  `registered_dataset_replacement_key` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `registered_dataset_name` varchar(128) DEFAULT NULL,
  `registered_dataset_source_url` varchar(128) DEFAULT NULL,
  `registered_dataset_local_url` varchar(128) DEFAULT NULL,
  `registered_dataset_description` text,
  `registered_dataset_notes` text,
  PRIMARY KEY (`registered_dataset_key`),
  UNIQUE KEY `dv_record_source_ix1` (`registered_dataset_key`) USING BTREE,
  KEY `dv_record_source_ix2` (`org_config_master_key`) USING BTREE,
  KEY `fk_dv_record_source_2` (`registered_dataset_steward`) USING BTREE,
  KEY `fk_dv_record_source_3` (`dv_record_content_type_key`) USING BTREE,
  CONSTRAINT `chameleon_dataset_registration_ibfk_1` FOREIGN KEY (`org_config_master_key`) REFERENCES `organization_config_master` (`org_config_master_key`),
  CONSTRAINT `chameleon_dataset_registration_ibfk_2` FOREIGN KEY (`registered_dataset_steward`) REFERENCES `person_party` (`person_party_key`),
  CONSTRAINT `chameleon_dataset_registration_ibfk_3` FOREIGN KEY (`dv_record_content_type_key`) REFERENCES `chameleon_record_content_type` (`dv_record_content_type_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7700000 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_dataset_routine
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_dataset_routine`;
CREATE TABLE `chameleon_dataset_routine` (
  `dataset_routine_key` int(11) NOT NULL AUTO_INCREMENT,
  `dataset_waypoint_key` int(11) NOT NULL,
  `dataset_routine_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `dataset_routine_type` varchar(64) DEFAULT NULL,
  `dataset_routine_name` varchar(128) DEFAULT NULL,
  `dataset_routine_directory` varchar(128) DEFAULT NULL,
  `dataset_routine_url` varchar(128) DEFAULT NULL,
  `dataset_routine_connection_string` varchar(255) DEFAULT NULL,
  `dataset_routine_notes` text,
  PRIMARY KEY (`dataset_routine_key`,`dataset_waypoint_key`),
  UNIQUE KEY `dv_record_source_ix1` (`dataset_routine_key`) USING BTREE,
  KEY `dv_record_source_ix2` (`dataset_waypoint_key`) USING BTREE,
  KEY `fk_dv_record_source_2` (`dataset_routine_steward`) USING BTREE,
  CONSTRAINT `chameleon_dataset_routine_ibfk_1` FOREIGN KEY (`dataset_routine_steward`) REFERENCES `person_party` (`person_party_key`),
  CONSTRAINT `chameleon_dataset_routine_ibfk_2` FOREIGN KEY (`dataset_waypoint_key`) REFERENCES `chameleon_dataset_waypoint` (`dataset_waypoint_key`)
) ENGINE=InnoDB AUTO_INCREMENT=88000000 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_dataset_waypoint
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_dataset_waypoint`;
CREATE TABLE `chameleon_dataset_waypoint` (
  `dataset_waypoint_key` int(11) NOT NULL AUTO_INCREMENT,
  `source_waypoint_key` int(11) DEFAULT NULL,
  `registered_dataset_key` int(11) DEFAULT NULL,
  `dataset_waypoint_steward` int(11) DEFAULT NULL,
  `replacement_dataset_waypoint_key` int(11) DEFAULT NULL,
  `data_lifecycle_phase_key` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `source_data_lifecycle_zone` varchar(64) DEFAULT NULL,
  `dataset_waypoint_name` varchar(128) DEFAULT NULL,
  `dataset_waypoint_notes` text,
  PRIMARY KEY (`dataset_waypoint_key`),
  UNIQUE KEY `uix_dataset_waypoint_1` (`dataset_waypoint_key`) USING BTREE,
  KEY `ix_dataset_waypoint_2` (`registered_dataset_key`) USING BTREE,
  KEY `ix_dataset_waypoint_3` (`dataset_waypoint_steward`) USING BTREE,
  KEY `ix_dataset_waypoint_4` (`source_waypoint_key`) USING BTREE,
  KEY `ix_dataset_waypoint_5` (`data_lifecycle_phase_key`),
  CONSTRAINT `fk_dataset_waypoint_1` FOREIGN KEY (`dataset_waypoint_steward`) REFERENCES `person_party` (`person_party_key`),
  CONSTRAINT `fk_dataset_waypoint_2` FOREIGN KEY (`registered_dataset_key`) REFERENCES `chameleon_dataset_registration` (`registered_dataset_key`),
  CONSTRAINT `fk_dataset_waypoint_3` FOREIGN KEY (`source_waypoint_key`) REFERENCES `chameleon_dataset_waypoint` (`dataset_waypoint_key`)
) ENGINE=InnoDB AUTO_INCREMENT=88000000 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chameleon_dataset_waypoint_grain
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_dataset_waypoint_grain`;
CREATE TABLE `chameleon_dataset_waypoint_grain` (
  `dataset_waypoint_grain_key` int(11) NOT NULL AUTO_INCREMENT,
  `dataset_waypoint_key` int(11) NOT NULL,
  `classification_facet_key` int(11) NOT NULL,
  `class_facet_value_key` int(11) NOT NULL,
  `data_owner` int(11) DEFAULT NULL,
  `data_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_waypoint_grain_key` int(11) DEFAULT NULL,
  `dataset_waypoint_grain_notes` text,
  PRIMARY KEY (`dataset_waypoint_grain_key`),
  UNIQUE KEY `uix_org_cg_ocgk_cfk_cfvk` (`dataset_waypoint_grain_key`,`classification_facet_key`,`class_facet_value_key`) USING BTREE,
  KEY `ix_org_cg_cfk_cfvk` (`classification_facet_key`,`class_facet_value_key`) USING BTREE,
  KEY `ix_org_cg_cfvk_cfk` (`class_facet_value_key`,`classification_facet_key`) USING BTREE,
  KEY `uix_org_cg_ocgk_ocmk` (`dataset_waypoint_key`) USING BTREE,
  CONSTRAINT `chameleon_dataset_waypoint_grain_ibfk_1` FOREIGN KEY (`classification_facet_key`) REFERENCES `chameleon_classification_facet` (`classification_facet_key`),
  CONSTRAINT `chameleon_dataset_waypoint_grain_ibfk_2` FOREIGN KEY (`class_facet_value_key`) REFERENCES `chameleon_class_facet_value` (`class_facet_value_key`),
  CONSTRAINT `chameleon_dataset_waypoint_grain_ibfk_3` FOREIGN KEY (`dataset_waypoint_key`) REFERENCES `chameleon_dataset_waypoint` (`dataset_waypoint_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for chameleon_record_content_type
-- ----------------------------
-- DROP TABLE IF EXISTS `chameleon_record_content_type`;
CREATE TABLE `chameleon_record_content_type` (
  `dv_record_content_type_key` int(11) NOT NULL AUTO_INCREMENT,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `content_type_replacement_key` int(11) DEFAULT NULL,
  `dv_record_content_type_name` varchar(512) DEFAULT NULL,
  `dv_record_content_type_notes` text,
  PRIMARY KEY (`dv_record_content_type_key`),
  UNIQUE KEY `dv_record_source_ix1` (`dv_record_content_type_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7700000 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for organization
-- ----------------------------
-- DROP TABLE IF EXISTS `organization`;
CREATE TABLE `organization` (
  `organization_party_key` int(11) NOT NULL AUTO_INCREMENT,
  `ref_iso_3166_1_surrogate_key` int(11) DEFAULT NULL,
  `organization_steward` int(11) DEFAULT NULL,
  `date_active` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_org_party_key` int(11) DEFAULT NULL,
  `organization_steward_email` varchar(255) DEFAULT NULL,
  `organization_name_short` varchar(255) DEFAULT NULL,
  `organization_name_long` varchar(512) DEFAULT NULL,
  `organization_notes` text,
  PRIMARY KEY (`organization_party_key`),
  UNIQUE KEY `uix_org_party_opk_alt` (`organization_party_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=55000001 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for organization_config_bind
-- ----------------------------
-- DROP TABLE IF EXISTS `organization_config_bind`;
CREATE TABLE `organization_config_bind` (
  `org_config_bind_key` int(11) NOT NULL AUTO_INCREMENT,
  `organization_party_key` int(11) NOT NULL,
  `org_config_master_key` int(11) NOT NULL,
  `data_owner` int(11) DEFAULT NULL,
  `data_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `dv_record_source_key` int(11) DEFAULT NULL,
  `replacement_config_bind_key` int(11) DEFAULT NULL,
  `org_config_bind_notes` text,
  PRIMARY KEY (`org_config_bind_key`),
  UNIQUE KEY `uix_org_cb_ocbk` (`org_config_bind_key`) USING BTREE,
  KEY `ix_org_cb_omk` (`organization_party_key`) USING BTREE,
  KEY `ix_org_cb_bcmk` (`org_config_master_key`) USING BTREE,
  CONSTRAINT `organization_config_bind_ibfk_1` FOREIGN KEY (`org_config_master_key`) REFERENCES `organization_config_master` (`org_config_master_key`),
  CONSTRAINT `organization_config_bind_ibfk_2` FOREIGN KEY (`organization_party_key`) REFERENCES `organization` (`organization_party_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for organization_config_grain
-- ----------------------------
-- DROP TABLE IF EXISTS `organization_config_grain`;
CREATE TABLE `organization_config_grain` (
  `org_config_grain_key` int(11) NOT NULL AUTO_INCREMENT,
  `org_config_master_key` int(11) NOT NULL,
  `classification_facet_key` int(11) NOT NULL,
  `class_facet_value_key` int(11) NOT NULL,
  `data_owner` int(11) DEFAULT NULL,
  `data_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_config_grain_key` int(11) DEFAULT NULL,
  `org_config_grain_notes` text,
  PRIMARY KEY (`org_config_grain_key`),
  UNIQUE KEY `uix_org_cg_ocgk_cfk_cfvk` (`org_config_grain_key`,`classification_facet_key`,`class_facet_value_key`) USING BTREE,
  KEY `ix_org_cg_cfk_cfvk` (`classification_facet_key`,`class_facet_value_key`) USING BTREE,
  KEY `ix_org_cg_cfvk_cfk` (`class_facet_value_key`,`classification_facet_key`) USING BTREE,
  KEY `uix_org_cg_ocgk_ocmk` (`org_config_master_key`) USING BTREE,
  CONSTRAINT `organization_config_grain_ibfk_1` FOREIGN KEY (`classification_facet_key`) REFERENCES `chameleon_classification_facet` (`classification_facet_key`),
  CONSTRAINT `organization_config_grain_ibfk_2` FOREIGN KEY (`class_facet_value_key`) REFERENCES `chameleon_class_facet_value` (`class_facet_value_key`),
  CONSTRAINT `organization_config_grain_ibfk_3` FOREIGN KEY (`org_config_master_key`) REFERENCES `organization_config_master` (`org_config_master_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for organization_config_master
-- ----------------------------
-- DROP TABLE IF EXISTS `organization_config_master`;
CREATE TABLE `organization_config_master` (
  `org_config_master_key` int(11) NOT NULL AUTO_INCREMENT,
  `udef_object_key` int(11) DEFAULT NULL,
  `data_owner` int(11) DEFAULT NULL,
  `data_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `dv_record_source_key` int(11) DEFAULT NULL,
  `replacement_config_master_key` int(11) DEFAULT NULL,
  `org_config_master_name` varchar(255) DEFAULT NULL,
  `org_config_master_notes` text,
  PRIMARY KEY (`org_config_master_key`),
  UNIQUE KEY `uix_org_cm_ocmk` (`org_config_master_key`) USING BTREE,
  UNIQUE KEY `uix_org_cm_ocmn` (`org_config_master_name`) USING BTREE,
  KEY `uix_org_cm_udefo_ocmn` (`udef_object_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3300000 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for organization_parent_org
-- ----------------------------
-- DROP TABLE IF EXISTS `organization_parent_org`;
CREATE TABLE `organization_parent_org` (
  `organization_hierachy_key` int(11) NOT NULL AUTO_INCREMENT,
  `organization_hierachy_name` varchar(512) NOT NULL,
  `parent_organization_key` int(11) DEFAULT NULL,
  `child_organization_key` int(11) DEFAULT NULL,
  `parent_depth_to_child` smallint(6) DEFAULT NULL,
  `organization_hierachy_steward` int(11) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_org_hierachy_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`organization_hierachy_key`),
  UNIQUE KEY `uix_org_hierarchy_ohk` (`organization_hierachy_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for person_party
-- ----------------------------
-- DROP TABLE IF EXISTS `person_party`;
CREATE TABLE `person_party` (
  `person_party_key` int(11) NOT NULL AUTO_INCREMENT,
  `organization_party_key` int(11) DEFAULT NULL,
  `udef_object_key` int(11) DEFAULT NULL,
  `person_email` varchar(255) NOT NULL,
  `person_demo_password` varchar(32) DEFAULT NULL,
  `form_of_address` varchar(128) NOT NULL,
  `first_name` varchar(128) NOT NULL,
  `middle_name` varchar(128) DEFAULT NULL,
  `surname` varchar(128) NOT NULL,
  `suffix_generation` varchar(128) DEFAULT NULL,
  `org_config_master_key` int(11) DEFAULT NULL,
  `record_trust_score` int(11) DEFAULT NULL,
  `record_trust_calculation_date` datetime DEFAULT NULL,
  `HOUSE_NUMBER` int(11) DEFAULT NULL,
  `PREC_STREET_QUALIFIER` varchar(128) DEFAULT NULL,
  `STREET_NAME` varchar(128) DEFAULT NULL,
  `STREET_TYPE` varchar(128) DEFAULT NULL,
  `SUCC_STREET_QUALIFIER` varchar(128) DEFAULT NULL,
  `SUBLOCATION` varchar(128) DEFAULT NULL,
  `CITY_TOWN` varchar(128) DEFAULT NULL,
  `URBANIZATION_NAME` varchar(128) DEFAULT NULL,
  `STATE_PROV_REGION` varchar(128) DEFAULT NULL,
  `POSTAL_CODE` varchar(128) DEFAULT NULL,
  `ISO_COUNTRY_ID` int(11) DEFAULT NULL,
  `PHONE_ACCESS_CODE` char(1) DEFAULT NULL,
  `PHONE_INTERNAT_CODE` varchar(32) DEFAULT NULL,
  `PHONE_TRUNK_CODE` varchar(32) DEFAULT NULL,
  `PHONE_NPA` varchar(32) DEFAULT NULL,
  `PHONE_LOCAL_LINE` varchar(32) DEFAULT NULL,
  `DATE_ACTIVE` datetime DEFAULT NULL,
  `DATE_EXPIRY` datetime DEFAULT NULL,
  `DATE_LAST_UPDATED` datetime DEFAULT NULL,
  `REPLACEMENT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`person_party_key`),
  UNIQUE KEY `uix_person_party_1` (`person_party_key`) USING BTREE,
  KEY `fk_person_party_2` (`org_config_master_key`),
  KEY `fk_person_party_1` (`organization_party_key`),
  KEY `ix_person_party_2` (`person_email`) USING BTREE,
  CONSTRAINT `fk_person_party_1` FOREIGN KEY (`organization_party_key`) REFERENCES `organization` (`organization_party_key`),
  CONSTRAINT `fk_person_party_2` FOREIGN KEY (`org_config_master_key`) REFERENCES `organization_config_master` (`org_config_master_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_adis_element
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_adis_element`;
CREATE TABLE `ref_adis_element` (
  `ADIS_ELEMENT_ID` int(11) NOT NULL,
  `ADIS_ELEMENT_ADIS_CODE` varchar(200) DEFAULT NULL,
  `ADIS_ELEMENT_DESC` varchar(200) DEFAULT NULL,
  `ADIS_ELEMENT_MAX_LENGTH` int(11) DEFAULT NULL,
  `ADIS_ELEMENET_DATA_TYPE` varchar(200) DEFAULT NULL,
  `ADIS_ELEMENT_MNEMONIC` varchar(200) DEFAULT NULL,
  `ADIS_ELEMENT_UPU_CODE` varchar(200) DEFAULT NULL,
  `ADIS_ELEMENT_ECCMA_CODE` varchar(200) DEFAULT NULL,
  `ADIS_ELEMENT_COMMENT` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ADIS_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_common_words
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_common_words`;
CREATE TABLE `ref_common_words` (
  `CommonWords_PrimaryKey` int(11) NOT NULL AUTO_INCREMENT,
  `Value` varchar(512) DEFAULT NULL,
  `Date_Added` datetime DEFAULT NULL,
  PRIMARY KEY (`CommonWords_PrimaryKey`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_entity_noun_type
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_entity_noun_type`;
CREATE TABLE `ref_entity_noun_type` (
  `entity_noun_type_locator` int(11) NOT NULL AUTO_INCREMENT,
  `entity_noun_type_name` varchar(255) DEFAULT NULL,
  `entity_noun_type_steward_notes` text,
  `entity_noun_type_data_steward` varchar(255) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_locator` int(11) DEFAULT NULL,
  PRIMARY KEY (`entity_noun_type_locator`),
  KEY `ix1_entity_class_copy_copy` (`entity_noun_type_locator`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_entity_reach
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_entity_reach`;
CREATE TABLE `ref_entity_reach` (
  `entity_reach_locator` int(11) NOT NULL AUTO_INCREMENT,
  `entity_reach_name` text,
  `entity_reach_steward_notes` text,
  `entity_reach_data_steward` varchar(255) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_locator` int(11) DEFAULT NULL,
  PRIMARY KEY (`entity_reach_locator`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_entity_role
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_entity_role`;
CREATE TABLE `ref_entity_role` (
  `entity_role_locator` int(11) NOT NULL AUTO_INCREMENT,
  `entity_role_name` text NOT NULL,
  `entity_role_data_steward` varchar(128) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `replacement_locator` int(11) DEFAULT NULL,
  PRIMARY KEY (`entity_role_locator`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_google_product_taxonomy
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_google_product_taxonomy`;
CREATE TABLE `ref_google_product_taxonomy` (
  `ref_google_prod_taxonomy_key` int(11) NOT NULL AUTO_INCREMENT,
  `gs1_segment_equivalent_node` varchar(255) DEFAULT NULL,
  `gs1_family_equivalent_node` varchar(255) DEFAULT NULL,
  `gs1_class_equivalent_node` varchar(255) DEFAULT NULL,
  `gs1_brick_equivalent_node` varchar(255) DEFAULT NULL,
  `google_sub_brick_level_1` varchar(255) DEFAULT NULL,
  `google_sub_brick_level_2` varchar(255) DEFAULT NULL,
  `google_sub_brick_level_3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ref_google_prod_taxonomy_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_attribute_fanset
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_attribute_fanset`;
CREATE TABLE `ref_gs1_attribute_fanset` (
  `Segment_Code` int(11) DEFAULT NULL,
  `Segment_Description` varchar(255) DEFAULT NULL,
  `Family_Code` int(11) DEFAULT NULL,
  `Family_Description` varchar(255) DEFAULT NULL,
  `Class_Code` int(11) DEFAULT NULL,
  `Class_Description` varchar(255) DEFAULT NULL,
  `Brick_Code` int(11) DEFAULT NULL,
  `Brick_Description` varchar(255) DEFAULT NULL,
  `Core_Attrib_Type_Code` int(11) DEFAULT NULL,
  `Core_Attrib_Type_Desc` varchar(255) DEFAULT NULL,
  `Core_Attrib_Value_Code` int(11) DEFAULT NULL,
  `Core_Attrib_Value_Desc` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_brick_classification
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_brick_classification`;
CREATE TABLE `ref_gs1_brick_classification` (
  `Segment_Code` int(11) DEFAULT NULL,
  `Segment_Description` varchar(255) DEFAULT NULL,
  `Family_Code` int(11) DEFAULT NULL,
  `Family_Description` varchar(255) DEFAULT NULL,
  `Class_Code` int(11) DEFAULT NULL,
  `Class_Description` varchar(255) DEFAULT NULL,
  `Brick_Code` int(11) DEFAULT NULL,
  `Brick_Description` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_1` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_1` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_2` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_2` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_3` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_3` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_4` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_4` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_5` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_5` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_6` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_6` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_7` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_7` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_8` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_8` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_9` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_9` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_10` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_10` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_11` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_11` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_12` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_12` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_13` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_13` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_14` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_14` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_15` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_15` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_16` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_16` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_17` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_17` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_18` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_18` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_19` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_19` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_20` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_20` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_21` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_21` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_22` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_22` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_23` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_23` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_24` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_24` varchar(255) DEFAULT NULL,
  `Core_Attrib_Code_25` int(11) DEFAULT NULL,
  `Core_Attrib_Desc_25` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_brick_facet_values
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_brick_facet_values`;
CREATE TABLE `ref_gs1_brick_facet_values` (
  `CLASSFACET_KEY` int(11) DEFAULT NULL,
  `FACET_VALUE_KEY` int(11) DEFAULT NULL,
  `Segment_Code` int(11) DEFAULT NULL,
  `Family_Code` int(11) DEFAULT NULL,
  `Class_Code` int(11) DEFAULT NULL,
  `Brick_Code` int(11) DEFAULT NULL,
  `LOAD_DATE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_brick_select_normal
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_brick_select_normal`;
CREATE TABLE `ref_gs1_brick_select_normal` (
  `FACET_VALUE_KEY` int(11) DEFAULT NULL,
  `CLASSFACET_KEY` int(11) DEFAULT NULL,
  `CFV_VALUE_INTEGER` int(11) DEFAULT NULL,
  `CFV_VALUE_ALPHA` varchar(255) DEFAULT NULL,
  `PARTY_ACCOUNT_KEY_OWN` int(11) DEFAULT NULL,
  `PARTY_ACCOUNT_KEY_LOAD` int(11) DEFAULT NULL,
  `DATE_LOADED` datetime DEFAULT NULL,
  `BRICK_CLASS_ANCHOR` int(11) DEFAULT NULL,
  UNIQUE KEY `IX_GS1_BRICK_SEL_NORMAL_1` (`FACET_VALUE_KEY`) USING BTREE,
  UNIQUE KEY `IX_GS1_BRICK_SEL_NORMAL_3` (`CFV_VALUE_INTEGER`) USING BTREE,
  KEY `IX_GS1_BRICK_SEL_NORMAL_2` (`CLASSFACET_KEY`) USING BTREE,
  KEY `IX_GS1_BRICK_SEL_NORMAL_4` (`BRICK_CLASS_ANCHOR`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_country_codes
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_country_codes`;
CREATE TABLE `ref_gs1_country_codes` (
  `ref_gs1_country_key` int(11) NOT NULL,
  `code_limit_low` varchar(16) DEFAULT NULL,
  `code_limit_high` varchar(16) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `data_steward_notes` text,
  PRIMARY KEY (`ref_gs1_country_key`),
  UNIQUE KEY `uix_ref_gs1_country_rgck` (`ref_gs1_country_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_family_to_class
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_family_to_class`;
CREATE TABLE `ref_gs1_family_to_class` (
  `FAM_CFV_VALUE_ALPHA` varchar(255) DEFAULT NULL,
  `FAM_CFV_VALUE_INTEGER` int(11) DEFAULT NULL,
  `FAM_CLASSFACET_KEY` int(11) DEFAULT NULL,
  `FAM_FACET_VALUE_KEY` int(11) DEFAULT NULL,
  `CLA_CLASSFACET_KEY` int(11) DEFAULT NULL,
  `CLA_FACET_VALUE_KEY` int(11) DEFAULT NULL,
  `SEG_CFV_VALUE_ALPHA` varchar(255) DEFAULT NULL,
  `CLA_CFV_VALUE_INTEGER` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_gs1_node_lookup
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_gs1_node_lookup`;
CREATE TABLE `ref_gs1_node_lookup` (
  `gs1_node_lookup_key` int(11) NOT NULL AUTO_INCREMENT,
  `gs1_segment_cfv_value_alpha` varchar(255) DEFAULT NULL,
  `gs1_family_cfv_value_alpha` varchar(255) DEFAULT NULL,
  `gs1_class_cfv_value_alpha` varchar(255) DEFAULT NULL,
  `gs1_brick_cfv_value_alpha` varchar(255) DEFAULT NULL,
  `gs1_class_facet_key_segment` int(11) DEFAULT NULL,
  `gs1_cfv_key_segment` int(11) DEFAULT NULL,
  `gs1_class_facet_key_family` int(11) DEFAULT NULL,
  `gs1_cfv_key_family` int(11) DEFAULT NULL,
  `gs1_class_facet_key_class` int(11) DEFAULT NULL,
  `gs1_cfv_key_class` int(11) DEFAULT NULL,
  `gs1_class_facet_key_brick` int(11) DEFAULT NULL,
  `gs1_cfv_key_brick` int(11) DEFAULT NULL,
  PRIMARY KEY (`gs1_node_lookup_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_10383_mic_code
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_10383_mic_code`;
CREATE TABLE `ref_iso_10383_mic_code` (
  `ref_iso_10383_surrogate_key` int(11) NOT NULL AUTO_INCREMENT,
  `market_country_code` char(2) DEFAULT NULL,
  `market_country_name` varchar(128) DEFAULT NULL,
  `market_city_name` varchar(64) DEFAULT NULL,
  `institution_description` varchar(255) DEFAULT NULL,
  `iso_assigned_mic_10383_code` varchar(8) DEFAULT NULL,
  `iso_assigned_acr_acronym_code` varchar(64) DEFAULT NULL,
  `data_vault_record_source_key` int(11) DEFAULT NULL,
  `dv_timestamp_data_vault_load` timestamp NULL DEFAULT NULL,
  `dv_timestamp_last_seen` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ref_iso_10383_surrogate_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_10962_fin_instruments_code
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_10962_fin_instruments_code`;
CREATE TABLE `ref_iso_10962_fin_instruments_code` (
  `REF_10962_KEY` int(11) NOT NULL,
  `REF_10962_CODE` varchar(16) DEFAULT NULL,
  `REF_10962_CODE_NAME` varchar(255) DEFAULT NULL,
  `REF_10962_CODE_DESCRIPTION` varchar(255) DEFAULT NULL,
  `DATE_ACTIVE` datetime DEFAULT NULL,
  `DATE_EXPIRY` datetime DEFAULT NULL,
  `DATE_LAST_UPDATED` datetime DEFAULT NULL,
  `REPLACEMENT_10962_KEY` int(11) DEFAULT NULL,
  PRIMARY KEY (`REF_10962_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_3166_1_country
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_3166_1_country`;
CREATE TABLE `ref_iso_3166_1_country` (
  `ref_iso_3166_1_surrogate_key` int(11) NOT NULL AUTO_INCREMENT,
  `ref_iso_3166_1_num_code` char(3) DEFAULT NULL,
  `ref_iso_3166_1_alpha_short_name` varchar(128) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `ref_iso_3166_1_replacement_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`ref_iso_3166_1_surrogate_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_3166_2_subdivision_usa
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_3166_2_subdivision_usa`;
CREATE TABLE `ref_iso_3166_2_subdivision_usa` (
  `ref_iso_3166_2_surrogate_key` int(11) NOT NULL AUTO_INCREMENT,
  `ref_iso_3166_2_assigned_code` varchar(8) DEFAULT NULL,
  `ref_iso_3166_2_alpha_2_code` varchar(8) DEFAULT NULL,
  `ref_iso_3166_2_subdivision_name` varchar(64) DEFAULT NULL,
  `ref_iso_3166_2_subdivision_category` varchar(32) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `ref_iso_3166_2_replacement_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`ref_iso_3166_2_surrogate_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_3166_country
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_3166_country`;
CREATE TABLE `ref_iso_3166_country` (
  `iso_3166_1_chameleon_key` int(11) NOT NULL,
  `iso_3166_1_numeric_code` varchar(200) DEFAULT NULL,
  `iso_3166_1_alpha_short_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`iso_3166_1_chameleon_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_4217_currency_code
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_4217_currency_code`;
CREATE TABLE `ref_iso_4217_currency_code` (
  `ref_iso_4217_surrogate_key` int(11) NOT NULL AUTO_INCREMENT,
  `ref_iso_4217_alpha_3_code` char(3) DEFAULT NULL,
  `ref_iso_4217_numeric_code` int(11) DEFAULT NULL,
  `ref_iso_4217_decimal_percision_used` smallint(6) DEFAULT NULL,
  `ref_iso_4217_currency_name` varchar(128) DEFAULT NULL,
  `ref_iso_4217_locations_using_currency` varchar(255) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `ref_iso_4217_replacement_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`ref_iso_4217_surrogate_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_iso_4217_currency_code_long
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_iso_4217_currency_code_long`;
CREATE TABLE `ref_iso_4217_currency_code_long` (
  `CMDR_4217_LOCATOR` int(11) NOT NULL,
  `ISO_4217_ALPHA_CODE` varchar(32) NOT NULL,
  `ISO_4217_NUMERIC_CODE` int(11) NOT NULL,
  `DECIMAL_PERCISION_SCALE` int(11) DEFAULT NULL,
  `ISO_4217_CURRENCY_NAME` varchar(128) NOT NULL,
  `LOCATIONS_USING_CURRENCY` varchar(255) DEFAULT NULL,
  `DATE_ACTIVE` datetime NOT NULL,
  `DATE_EXPIRY` datetime DEFAULT NULL,
  `DATE_LAST_UPDATED` datetime NOT NULL,
  `REPLACEMET_4217_LOCATOR` int(11) DEFAULT NULL,
  PRIMARY KEY (`CMDR_4217_LOCATOR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_naics_codes
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_naics_codes`;
CREATE TABLE `ref_naics_codes` (
  `CHAMELEON_KEY` int(11) NOT NULL,
  `naics_code` varchar(255) DEFAULT NULL,
  `naics_title` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`CHAMELEON_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_chunker_ner_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_chunker_ner_tags`;
CREATE TABLE `ref_nlp_chunker_ner_tags` (
  `nlp_chunker_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `token_example` varchar(64) DEFAULT NULL,
  `io_tag` varchar(64) DEFAULT NULL,
  `bio_tag` varchar(64) DEFAULT NULL,
  `bmewo_tag` varchar(64) DEFAULT NULL,
  `bmewo_plus_tag` varchar(64) DEFAULT NULL,
  `bilou_tag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`nlp_chunker_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_conll2002_named_entity_types
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_conll2002_named_entity_types`;
CREATE TABLE `ref_nlp_conll2002_named_entity_types` (
  `named_entity_type_locator` int(11) NOT NULL AUTO_INCREMENT,
  `named_entity_type` varchar(64) DEFAULT NULL,
  `named_entity_type_tag` varchar(64) DEFAULT NULL,
  `named_entity_type_description` text,
  `named_entity_type_source_url` varchar(64) DEFAULT 'http://http://www.cnts.ua.ac.be/conll2002/ner/',
  PRIMARY KEY (`named_entity_type_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_dependency_labels
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_dependency_labels`;
CREATE TABLE `ref_nlp_dependency_labels` (
  `nlp_dependency_label_locator` int(11) NOT NULL AUTO_INCREMENT,
  `dependency_label` varchar(64) DEFAULT NULL,
  `dependency_label_description` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`nlp_dependency_label_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_encoding_schemes
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_encoding_schemes`;
CREATE TABLE `ref_nlp_encoding_schemes` (
  `ref_nlp_encoding_scheme_locator` int(11) NOT NULL AUTO_INCREMENT,
  `ref_nlp_encoding_scheme_name` varchar(64) DEFAULT NULL,
  `ref_nlp_encoding_scheme_description` varchar(255) DEFAULT NULL,
  `nlp_chunker_scheme_type_tags` varchar(255) DEFAULT NULL,
  `nlp_chunker_scheme_type_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ref_nlp_encoding_scheme_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_ice_corpus_of_english_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_ice_corpus_of_english_tags`;
CREATE TABLE `ref_nlp_ice_corpus_of_english_tags` (
  `amalgam_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `amalgam_tag_value` varchar(64) DEFAULT NULL,
  `amalgam_description` varchar(255) DEFAULT NULL,
  `amalgam_example_text` varchar(255) DEFAULT NULL,
  `tagset_name` varchar(128) DEFAULT NULL,
  `tagset_scheme_description` text,
  PRIMARY KEY (`amalgam_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_named_entity_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_named_entity_tags`;
CREATE TABLE `ref_nlp_named_entity_tags` (
  `named_entity_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `named_entity_tag` varchar(32) DEFAULT NULL,
  `may_follow` varchar(64) DEFAULT NULL,
  `may_precede` varchar(64) DEFAULT NULL,
  `named_entity_tag_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`named_entity_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_penn_treebank2_anchor_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_penn_treebank2_anchor_tags`;
CREATE TABLE `ref_nlp_penn_treebank2_anchor_tags` (
  `penn_treebank2_relation_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `relation_tag` varchar(32) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `example_relation` varchar(255) DEFAULT NULL,
  `chunk_type` varchar(32) DEFAULT NULL,
  `chunk_type_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`penn_treebank2_relation_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_penn_treebank2_chunck_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_penn_treebank2_chunck_tags`;
CREATE TABLE `ref_nlp_penn_treebank2_chunck_tags` (
  `penn_treebank2_chunk_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `penn_treebank2_chunk_tag` varchar(32) DEFAULT NULL,
  `tag_description` varchar(128) DEFAULT NULL,
  `chunk_pos_tag_sequence` varchar(64) DEFAULT NULL,
  `example_chunk` varchar(255) DEFAULT NULL,
  `base_pct_chunks_this_type` int(11) DEFAULT NULL,
  `chunk_type` varchar(32) DEFAULT NULL,
  `chunk_type_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`penn_treebank2_chunk_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_penn_treebank2_pos_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_penn_treebank2_pos_tags`;
CREATE TABLE `ref_nlp_penn_treebank2_pos_tags` (
  `penn_treebank_pos_locator` int(11) NOT NULL AUTO_INCREMENT,
  `penn_treebank_tag` varchar(32) DEFAULT NULL,
  `tag_description` varchar(128) DEFAULT NULL,
  `example_text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`penn_treebank_pos_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_penn_treebank2_relation_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_penn_treebank2_relation_tags`;
CREATE TABLE `ref_nlp_penn_treebank2_relation_tags` (
  `penn_treebank2_relation_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `relation_tag` varchar(32) DEFAULT NULL,
  `description` varchar(64) DEFAULT NULL,
  `chunk_tag_sequence` varchar(64) DEFAULT NULL,
  `example_relation` varchar(255) DEFAULT NULL,
  `base_pct_relations_this_type` int(11) DEFAULT NULL,
  `chunk_type` varchar(32) DEFAULT NULL,
  `chunk_type_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`penn_treebank2_relation_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_propbank_modifier_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_propbank_modifier_tags`;
CREATE TABLE `ref_nlp_propbank_modifier_tags` (
  `modifier_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `modifier_tag_value` varchar(32) DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `tagset_name` varchar(128) DEFAULT NULL,
  `tagset_url` varchar(255) DEFAULT NULL,
  `tagset_description` text,
  PRIMARY KEY (`modifier_tag_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_nlp_propbank_semantic_role_tags
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_nlp_propbank_semantic_role_tags`;
CREATE TABLE `ref_nlp_propbank_semantic_role_tags` (
  `numbered_argument_locator` int(11) NOT NULL AUTO_INCREMENT,
  `numbered_argument_tag_value` varchar(32) DEFAULT NULL,
  `typical_semantic_role` varchar(128) DEFAULT NULL,
  `tagset_name` varchar(128) DEFAULT NULL,
  `tagset_url` varchar(255) DEFAULT NULL,
  `tagset_description` text,
  PRIMARY KEY (`numbered_argument_locator`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_sbvr_concept
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_sbvr_concept`;
CREATE TABLE `ref_sbvr_concept` (
  `concept_type_key` int(11) NOT NULL AUTO_INCREMENT,
  `concept_name` varchar(255) DEFAULT NULL,
  `concept_also_known_as` varchar(255) DEFAULT NULL,
  `concept_sbvr_definition` text,
  `concept_representation_in_profile` text,
  `concept_sbvr_notes` text,
  `concept_representation_notes` text,
  PRIMARY KEY (`concept_type_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_sbvr_logical_operators
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_sbvr_logical_operators`;
CREATE TABLE `ref_sbvr_logical_operators` (
  `logical_operation_key` int(11) NOT NULL AUTO_INCREMENT,
  `logical_operation_name` varchar(255) DEFAULT NULL,
  `logical_operation_atm_representation` text,
  `logical_operation_meaning` text,
  PRIMARY KEY (`logical_operation_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_sbvr_modality
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_sbvr_modality`;
CREATE TABLE `ref_sbvr_modality` (
  `modality_key` int(11) NOT NULL AUTO_INCREMENT,
  `modality_name` varchar(255) DEFAULT NULL,
  `modality_atm_representation` text,
  `transformation_using_negations` text,
  PRIMARY KEY (`modality_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_sbvr_quantification
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_sbvr_quantification`;
CREATE TABLE `ref_sbvr_quantification` (
  `quantification_key` int(11) NOT NULL AUTO_INCREMENT,
  `quantification_name` varchar(255) DEFAULT NULL,
  `quantification_atm_representation` text,
  `quantification_description` text,
  PRIMARY KEY (`quantification_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_semantic_tag
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_semantic_tag`;
CREATE TABLE `ref_semantic_tag` (
  `semantic_tag_locator` int(11) NOT NULL AUTO_INCREMENT,
  `semantic_tag_type` int(11) DEFAULT NULL,
  `semantic_tag_text_string` text,
  `ref_udef_property_locator` int(11) DEFAULT NULL,
  `semantic_tag_stewasrd_notes` text,
  `date_active` datetime DEFAULT NULL,
  PRIMARY KEY (`semantic_tag_locator`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_semantic_tag_type
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_semantic_tag_type`;
CREATE TABLE `ref_semantic_tag_type` (
  `semantic_tag_type_locator` int(11) NOT NULL AUTO_INCREMENT,
  `semantic_tag_type_name` text,
  `semantic_tag_stewasrd_notes` text,
  `date_active` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`semantic_tag_type_locator`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_semantic_tag_value
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_semantic_tag_value`;
CREATE TABLE `ref_semantic_tag_value` (
  `semantic_tag_value_locator` int(11) NOT NULL AUTO_INCREMENT,
  `semantic_tag_locator` int(11) DEFAULT NULL,
  `semantic_tag_type` int(11) DEFAULT NULL,
  `tag_value_string` text,
  `date_loaded` datetime DEFAULT NULL,
  PRIMARY KEY (`semantic_tag_value_locator`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_udef_object
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_udef_object`;
CREATE TABLE `ref_udef_object` (
  `udef_object_key` int(11) NOT NULL AUTO_INCREMENT,
  `udef_object_parent_class` int(11) DEFAULT NULL,
  `udef_object_assigned_code` varchar(128) DEFAULT NULL,
  `udef_object_assigned_name` varchar(128) DEFAULT NULL,
  `udef_object_assigned_definition` varchar(512) DEFAULT NULL,
  `udef_object_url` varchar(128) DEFAULT NULL,
  `date_active` datetime NOT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `udef_object_replacement_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`udef_object_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_udef_property
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_udef_property`;
CREATE TABLE `ref_udef_property` (
  `udef_property_key` int(11) NOT NULL AUTO_INCREMENT,
  `udef_property_parent_class` int(11) NOT NULL,
  `udef_property_assigned_code` varchar(128) NOT NULL,
  `udef_property_assigned_name` varchar(128) DEFAULT NULL,
  `udef_property_assigned_definition` varchar(512) DEFAULT NULL,
  `udef_property_url` varchar(128) DEFAULT NULL,
  `date_active` datetime DEFAULT NULL,
  `date_expiry` datetime DEFAULT NULL,
  `udef_property_replacement_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`udef_property_key`),
  UNIQUE KEY `UIX_UDEF_PROPERTY_KEY` (`udef_property_key`,`udef_property_assigned_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for ref_uom_english_2_metric
-- ----------------------------
-- DROP TABLE IF EXISTS `ref_uom_english_2_metric`;
CREATE TABLE `ref_uom_english_2_metric` (
  `CHAMELEON_UOM_KEY` int(11) NOT NULL AUTO_INCREMENT,
  `CHAMELEON_UOM_NAME` varchar(255) DEFAULT NULL,
  `FACET_DESCRIPTION` varchar(255) DEFAULT NULL,
  `PARENT_CLASS_FACET_KEY` int(11) DEFAULT NULL,
  `PARENT_CLASS_FACET_NAME` varchar(255) DEFAULT NULL,
  `CHAMELEON_DATA_DOMAIN` int(11) DEFAULT NULL,
  `CHAMELEON_FACET_TYPE` int(11) DEFAULT NULL,
  `METRIC_EQUIV_MEASURE` varchar(255) DEFAULT NULL,
  `CONVERT_ENG_2_METRIC_MULTIPLER` decimal(28,10) DEFAULT NULL,
  PRIMARY KEY (`CHAMELEON_UOM_KEY`),
  UNIQUE KEY `UIX_OUM_KEY` (`CHAMELEON_UOM_KEY`) USING BTREE,
  KEY `NUIX_OUM_CLASS_FACET` (`PARENT_CLASS_FACET_KEY`) USING BTREE,
  KEY `NUIX_OUM_DATA_DOMAIN` (`CHAMELEON_DATA_DOMAIN`) USING BTREE,
  KEY `NUIX_OUM_FACET_TYPE` (`CHAMELEON_FACET_TYPE`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

